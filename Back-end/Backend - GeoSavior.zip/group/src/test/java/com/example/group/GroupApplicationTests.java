package com.example.group;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
