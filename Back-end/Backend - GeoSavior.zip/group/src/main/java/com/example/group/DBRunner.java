package com.example.group;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import com.example.group.model.*;
import com.example.group.model.*;
import com.example.group.repository.*;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DBRunner  implements CommandLineRunner{

	@Autowired 
	private EventRepository therapistRepository;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		therapistRepository.deleteAll();

		Event newUser;

		newUser = new Event( " Charity Event", " Uxbridge,Middlesex"," GeoSaviors",90,new GregorianCalendar(2023, Calendar.APRIL, 06).getTime(),new GregorianCalendar(2023, Calendar.APRIL, 10).getTime(),"main");

		therapistRepository.save(newUser);

		Event newUser1;

		newUser1 = new Event( " Fundraising", " Hillingdon,Middlesex","GeoSaviors",90,new GregorianCalendar(2023, Calendar.APRIL, 07).getTime(),new GregorianCalendar(2023, Calendar.APRIL, 11).getTime(),"main");

		therapistRepository.save(newUser1);

		Event newUser2;

		newUser2 = new Event( " Donations for Turkey", " Uxbridge,Middlesex"," GeoSaviors",90,new GregorianCalendar(2023, Calendar.APRIL, 10).getTime(),new GregorianCalendar(2023, Calendar.APRIL, 15).getTime(),"main");

		therapistRepository.save(newUser2);
	}

}
