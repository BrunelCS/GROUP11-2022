package com.example.group.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import jakarta.persistence.*;


import org.springframework.data.jpa.domain.support.AuditingEntityListener;



//Let's create a simple User class
@Entity
@Table(name = "events")
@EntityListeners(AuditingEntityListener.class)
public class Event implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long event_id;



	//@Column(nullable=false)
	//String name;




	
	String title;

	String address;
	
	String organizer;
	
	

	float fee;
	
	Date start_date;
	
	Date end_date;
	
	String content;





	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getOrganizer() {
		return organizer;
	}


	public void setOrganizer(String organizer) {
		this.organizer = organizer;
	}


	public float getFee() {
		return fee;
	}


	public void setFee(float fee) {
		this.fee = fee;
	}


	public Date getStart_date() {
		return start_date;
	}


	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}


	public Date getEnd_date() {
		return end_date;
	}


	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}


	


	


	@Override
	public String toString() {
		return "Event [id=" + event_id + ", name="  + ", title=" + title + ", address=" + address + ", organizer="
				+ organizer + ", fee=" + fee + ", start_date=" + start_date + ", end_date=" + end_date + ", content="
				+ content + "]";
	}


	


	public Event( String title, String address, String organizer, float fee, Date start_date, Date end_date,
			String content) {
		super();
		//this.name = name;
		this.title = title;
		this.address = address;
		this.organizer = organizer;
		this.fee = fee;
		this.start_date = start_date;
		this.end_date = end_date;
		this.content = content;
	}


	

	


/*	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

*/
	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}











	

	


}
