package com.example.group.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.group.model.Event;


public interface EventRepository extends CrudRepository<Event,Long>{

}
