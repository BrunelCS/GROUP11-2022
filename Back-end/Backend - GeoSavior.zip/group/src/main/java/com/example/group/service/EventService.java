package com.example.group.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.group.model.Event;
import com.example.group.repository.EventRepository;

@Service
public class EventService {
	@Autowired
    EventRepository eventRepository;
	
	public  EventService()
		// TODO Auto-generated constructor stub
	 {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public List<Event> getUsers() {
		return (List<Event>) eventRepository.findAll();
	}

	
	public void addUser(Event newEvent) {
		eventRepository.save(newEvent);
	}
	
	public Optional<Event> findByID(Long id) {
		 return eventRepository.findById(id);
	}
	
	public void deleteUser(Long id) {
		Event user = eventRepository.findById(id)
				  .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		eventRepository.delete(user);
	}
	
	

}
