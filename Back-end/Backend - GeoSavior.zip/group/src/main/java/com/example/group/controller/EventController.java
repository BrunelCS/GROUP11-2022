package com.example.group.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.group.dto.EventPostDTO;
import com.example.group.model.Event;
import com.example.group.service.EventService;


@RestController  
public class EventController {
	
	@Autowired
	EventService eventService;


	// Get All Users
    @GetMapping("/user")
    public List<Event> getUsers() {
        return eventService.getUsers();
    }
    
    @PostMapping("/user")
    public ResponseEntity<Optional<Event>> addUser(@RequestBody EventPostDTO newUserDTO) {
    	
    	if (
    		newUserDTO.getTitle()==null ||
    		newUserDTO.getAddress()==null ||
    		newUserDTO.getFee() == 0 ||
    		newUserDTO.getStart_date()== null ||
    		newUserDTO.getEnd_date()== null ||
    		newUserDTO.getContent()==null ||
    		newUserDTO.getOrganizer()==null) {
            return new ResponseEntity<>(Optional.ofNullable(null), HttpStatus.BAD_REQUEST);
        }
    	
    	Event newUser = new Event( newUserDTO.getTitle(),
    			newUserDTO.getAddress(), newUserDTO.getOrganizer(),newUserDTO.getFee(),newUserDTO.getStart_date(),newUserDTO.getEnd_date(),newUserDTO.getContent());
    	eventService.addUser(newUser);
    	return new ResponseEntity<>(Optional.ofNullable(newUser),HttpStatus.CREATED);

    }
	 
    
    // Get User by ID
    @GetMapping("/user/{id}")
    public Optional<Event> getUserById(@PathVariable(value = "id") long Id) {
        return eventService.findByID(Id);
    }
    
    
    //Delete a User by ID
    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable(value = "id") long Id) {
    	eventService.deleteUser(Id);
        return "User Deleted"; 
    }
}